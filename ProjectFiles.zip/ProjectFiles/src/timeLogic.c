#include "timeLogic.h"
#include "dispArrays.h"
#include "microblaze_sleep.h"

/*
 * Definitions of functions prototyped in the timeLogic header file. These functions and their arguments
 * are described in that file.
 * */

void setTime(struct Time *t, int hr, int min, int sec)
{
	t->hour = hr;
	t->minute = min;
	t->second = sec;
}

void incrementSecond(struct Time *t)
{
	// Logic for incrementing second value of a Time structure.
	if(t->second == 59)
	{
		t->second = 0;
		incrementMinute(t);
	}
	else
		t->second++;
}

void incrementMinute(struct Time *t)
{
	// Logic for incrementing minute value of a Time structure.
	if(t->minute == 59)
	{
		t->minute = 0;
		incrementHour(t);
	}
	else
		t->minute++;
}

void incrementHour(struct Time *t)
{
	// Logic for incrementing hour value of a Time structure.
	if(t->isHour12)
	{
		if(t->hour == 12)
			t->hour = 1;
		else
			t->hour++;
	}
	else
	{
		if(t->hour == 23)
			t->hour = 0;
		else
			t->hour++;
	}
}

void progSecond(struct Time *t, int val)
{
	// Logic for programming the second value of a Time structure.
	t->second += val;
	if(t->second > 59)
		t->second = 0;
	if(t->second < 0)
		t->second = 59;
}

void progMinute(struct Time *t, int val)
{
	// Logic for programming the minute value of a Time structure.
	t->minute += val;
	if(t->minute > 59)
		t->minute = 0;
	if(t->minute < 0)
		t->minute = 59;
}

void progHour(struct Time *t, int val)
{
	// Logic for programming the hour value of a Time structure.
	t->hour += val;
	if(t->hour > 12)
		t->hour = 1;
	if(t->hour < 1)
		t->hour = 12;
}

// Function for displaying the time. Can display either the clock time or alarm time. Argument 't' is the
// Time to be displayed, argument '*disp' is a pointer to the seven segment display to output the time on.
void displayTime(struct Time *t, XGpio *disp)
{
	// Extract digits of the Time. Even indices are ones places, odd indices are tens places.
	int extractedDigits[6] =
	{
		t->second % 10,
		(int) t->second / 10,
		t->minute % 10,
		(int) t->minute / 10,
		t->hour % 10,
		(int) t->hour / 10
	};
	// Loop to display the extracted digits in the appropriate segment of the display.
	for(int i = 0; i < 6; i++)
	{
		// Anode of the display
		XGpio_SetDataDirection(disp, 2, dispPlace[i]);
		// Cathode of the display
		XGpio_SetDataDirection(disp, 1, dispDigit[extractedDigits[i]]);
		// Delay to avoid flickering
		MB_Sleep(2);
	}
}
