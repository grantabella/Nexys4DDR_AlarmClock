#include "xil_types.h"

/*
 * Header file containing arrays related to the seven segment display:
 * 		dispDigit	:	u32 containing the cathode values for digits.
 * 		dispPlace	:	u32 containing the anode values for each section
 * 						of the display.
 * 		dispLetter	:	u32 containing the cathode values for letters.
 * */

static const u32 dispDigit[11] =
{
    //Pgfedcba
	0b11000000, // 0
	0b11111001, // 1
	0b10100100, // 2
	0b10110000, // 3
	0b10011001, // 4
	0b10010010, // 5
	0b10000010, // 6
	0b11111000, // 7
	0b10000000, // 8
	0b10011000, // 9
	0b11111111  // blank
};

static const u32 dispPlace[8] =
{
    //87654321
	0b11111110,
	0b11111101,
	0b11111011,
	0b11110111,
	0b11101111,
	0b11011111,
	0b10111111,
	0b01111111
};

static const u32 dispLetter[18] =
{
	//Pgfedcba
	0b10001000, //A
	0b10000011, //b
	0b11000110, //C
	0b10100111, //c
	0b10100001, //d
	0b10000110, //E
	0b10001110, //F
	0b10010000, //g
	0b10000010, //G
	0b10001001, //H
	0b10001011, //h
	0b11000111, //L
	0b11111001, //l
	0b10101011, //n
	0b11000000, //O
	0b10100011, //o
	0b10001100, //P
	0b10010010  //S
};
