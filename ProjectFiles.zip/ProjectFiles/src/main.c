#include <stdio.h>
#include "xparameters.h"
#include "xgpio.h"
#include <xtmrctr.h>
#include <xintc.h>
#include "xil_exception.h"
#include "microblaze_sleep.h"
#include "mb_interface.h"
#include "timeLogic.h"
#include "dispArrays.h"

/*
 	#####################################################################################
	#	Engineer:				Grant Abella, ECE Junior								#
	#	Institution:			Bradley University										#
	#	Course:					ECE 482													#
	#	Professor:				Dr. Lu													#
	#																					#
	#	Project:				Digital Alarm Clock										#
	#	Project Description:	Designed for Digilent Nexyxs 4 DDR, the user can		#
	#							program a 12-hour clock. Users also have the option		#
	#							of enabling and programming an alarm associated with	#
	#							that clock.												#
	#																					#
	#	GPIO:					1 eight-digit seven segment display						#
	#							1 LED:			LD16 blinks when alarm is triggered.	#
	#							2 pushbuttons: 	BTNU increments selected time digit.	#
	#											BTND decrements selected time digit.	#
	#							4 dip switches:	SW0 sets time seconds or alarm seconds 	#
	#											 to be programmable.					#
	#											SW1 sets time minutes or alarm minutes	#
	#											 to be programmable.					#
	#											SW2 sets time hours or alarm hours to 	#
	#											 be programmable.						#
	#####################################################################################
 */

// Function prototypes
void displayTimeBlink(struct Time *t, XGpio *disp, u32 selection);
void checkAlarm(struct Time t);

// True/false definitions for booleans
#define false 0
#define true 1

// Boolean declarations
_Bool toggleSec = false;		// boolean is flipped true/false every second
_Bool on = true;				// for blinking the seven segment display when programming times
_Bool alarmEnabled = false;		// turned true if switch 15 is on
_Bool alarmTriggered = false;	// turns true if clock time equals alarm time

// The instance of the main timer and the debouncing timer.
XTmrCtr timer, deb;

// The instance of the interrupt controller
XIntc clockIntCont;

// The instance of the dip switches, seven segment display, push buttons, and the alarm led.
XGpio dip, disp, btn, led;

// Time structures. x is the clock time, a is alarm time. In main(), a is assigned as x's alarm.
struct Time x, a;

// Function for handling button presses during time programming. Called in btn_handler()
// Argument 'selection' is the dip switches status.
void btn_handler(u32 selection)
{
	if(XTmrCtr_GetValue(&deb, 0) > 0xFDFF0F00)				// slows down the button presses
	{
		XTmrCtr_Reset(&deb,0);								// reset debouncing timer
		XTmrCtr_Start(&deb,0);								// restarts debouncing timer
		switch(selection)									// checking which switches are on
		{
		case 1:												// switch 0 is on
			if(XGpio_DiscreteRead(&btn,1) == 2)
			{
				progSecond(&x, 1);
			}
			if(XGpio_DiscreteRead(&btn,1) == 16)
			{
				progSecond(&x, -1);
			}
			break;
		case 2:												// switch 1 is on
			if(XGpio_DiscreteRead(&btn,1) == 2)
			{
				progMinute(&x, 1);
			}
			if(XGpio_DiscreteRead(&btn,1) == 16)
			{
				progMinute(&x, -1);
			}
			break;
		case 4:												// switch 2 is on
			if(XGpio_DiscreteRead(&btn,1) == 2)
			{
				progHour(&x, 1);
			}
			if(XGpio_DiscreteRead(&btn,1) == 16)
			{
				progHour(&x, -1);
			}
			break;
		case 32769:											// switches 0 and 15 are on
			if(XGpio_DiscreteRead(&btn,1) == 2)
			{
				progSecond(x.alarm, 1);
			}
			if(XGpio_DiscreteRead(&btn,1) == 16)
			{
				progSecond(x.alarm, -1);
			}
			break;
		case 32770:											// switches 1 and 15 are on
			if(XGpio_DiscreteRead(&btn,1) == 2)
			{
				progMinute(x.alarm, 1);
			}
			if(XGpio_DiscreteRead(&btn,1) == 16)
			{
				progMinute(x.alarm, -1);
			}
			break;
		case 32772:											// switches 2 and 15 are on
			if(XGpio_DiscreteRead(&btn,1) == 2)
			{
				progHour(x.alarm, 1);
			}
			if(XGpio_DiscreteRead(&btn,1) == 16)
			{
				progHour(x.alarm, -1);
			}
			break;
		}
	}
}
// Function for handling the dip switches. Reads status and calls btn_handler().
void dip_handler()
{
	u32 dipValue = XGpio_DiscreteRead(&dip,1);			// Gets value of the switches

	switch(dipValue)									// Checking switch values
	{
	// If any of the six possible values are read from the register, call btn_handler().
	// Otherwise leave the function.
	case 1:
	case 2:
	case 4:
	case 32769:
	case 32770:
	case 32772:
		btn_handler(dipValue);
		break;
	default:
		return;
	}
	// If alarm is enabled, start blinking for the alarm Time.
	if (alarmEnabled)
		displayTimeBlink(x.alarm, &disp, dipValue);
	// Otherwise start blinking the clock.
	else
		displayTimeBlink(&x, &disp, dipValue);
}

// Interrupt handler for the timer. Called in the interrupt handler.
void timer_int_handler(void * baseaddr_p)
{
		toggleSec = true;
		// Stop, reset, and restart the timer.
        XTmrCtr_Stop(&timer,0);
        XTmrCtr_Reset(&timer,0);
        XTmrCtr_Start(&timer,0);
}

// Interrupt handler that calls timer_int_handler();
void clkIntHandler(void)
{
	// Call timer_int_handler Interrupt handler.
	timer_int_handler(&timer);
}

// Main program function.
int main(void)
{
	// Set initial time of the clock.
	setTime(&x, 11, 59, 40);
	// Asign a as the alarm to x
	x.alarm = &a;
	// Set initial time of the alarm.
	setTime(&a, 12, 0, 0);

	/*
	 * Functions related to timers and interrupts
	 *
	 * */

	// Initialize the Timer counter
	XTmrCtr_Initialize(&timer, XPAR_AXI_TIMER_0_DEVICE_ID);
	// Initialize thedebouncing timer
	XTmrCtr_Initialize(&deb,XPAR_AXI_TIMER_1_DEVICE_ID);
	// Initialize the Interrupt Controller
	XIntc_Initialize(&clockIntCont, XPAR_MICROBLAZE_0_AXI_INTC_DEVICE_ID);
	// Connect a handler to be called when interrupt occurs
	XIntc_RegisterHandler(XPAR_MICROBLAZE_0_AXI_INTC_BASEADDR, XPAR_INTC_0_TMRCTR_0_VEC_ID,
							(XInterruptHandler)clkIntHandler, &clockIntCont);
	// Start Interrupt Controller so interrupts are enabled
	// for all devices that cause interrupts.
	XIntc_Start(&clockIntCont, XIN_REAL_MODE);
	// Enable the interrupt for the Timer
	XIntc_Enable(&clockIntCont, XPAR_INTC_0_TMRCTR_0_VEC_ID);
	// Initialize the exception table
	Xil_ExceptionInit();
	// Register the Interrupt Controller handler with the exception table
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler) XIntc_InterruptHandler, &clockIntCont);
	// Enable non-critical exceptions
	Xil_ExceptionEnable();
	// Set handler for Timer
	XTmrCtr_SetHandler(&timer, (XTmrCtr_Handler) timer_int_handler,&timer);
	// Set interrupt of Timer to occur and auto reload
	XTmrCtr_SetOptions(&timer, 0, XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);
	// Set interrupt of debouncing timer to occur and auto reload
	XTmrCtr_SetOptions(&deb, 0, XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);
	// Set timer reset value
	XTmrCtr_SetResetValue(&timer, 0, 0xFD050F7F);
	// Set debouncing timer reset value
	XTmrCtr_SetResetValue(&deb, 0, 0xFD050F7F);
	// Start the Timer
	XTmrCtr_Start(&timer, 0);
	// Start the debouncing timer
	XTmrCtr_Start(&deb, 0);

	/*
	 * Functions related to gpio devices
	 *
	 * */

	// Initialize the seven segment display. Data direction and discrete values are both
	// set in displayTime() and displayTimeBlink() functions.
	XGpio_Initialize(&disp, XPAR_DISP_DEVICE_ID);

	// Initialize the dip switches and set all to input.
	XGpio_Initialize(&dip, XPAR_SWITCHES_DEVICE_ID);
	XGpio_SetDataDirection(&dip, 1, 0x11111111);

	// Initialize buttons and set all to input.
	XGpio_Initialize(&btn, XPAR_BUTTONS_DEVICE_ID);
	XGpio_SetDataDirection(&btn, 1, 0x11111111);

	// Initialize led and set as output
	XGpio_Initialize(&led, XPAR_RGBLED_DEVICE_ID);
	XGpio_SetDataDirection(&led, 1, ~0x01);

	// Main while loop where program lives after initializations of Times, timers and gpio devices
	while(1)
	{
		// Display time of x on the seven segment display.
		displayTime(&x, &disp);

		// If alarm is triggered, toggle the led.
		if (alarmTriggered)
		{
			u32 timerVal = XTmrCtr_GetValue(&timer, 0);
			u32 Data = XGpio_DiscreteRead(&led, 1);
			if(timerVal > 0xFE8287BF)
				XGpio_DiscreteWrite(&led, 1, Data & ~0x01);
			else
				XGpio_DiscreteWrite(&led, 1, Data | 0x01);
		}
		// If timer interrupt controller has set toggleSec to true, increment the second on clock.
		if(toggleSec == true)
		{
			incrementSecond(&x);
			toggleSec = false;						// turn off toggleSec
		}
		if(alarmEnabled)
			checkAlarm(x);							// if alarm is enabled, check if it should trigger.
		// Program resides here if any of the programming switches are on, except if switch 15 to enable
		// the alarm is the only switch turned on. Calls dip_handler().
		while(XGpio_DiscreteRead(&dip,1) != 0 && XGpio_DiscreteRead(&dip,1) != 32768)
		{
			dip_handler();
		}
		// If switch 15 is on, enable the alarm
		if (XGpio_DiscreteRead(&dip,1) >= 32768)
			alarmEnabled = true;
		// Otherwise disable the alarm.
		else
			alarmEnabled = false;

	}
	return 0;
}

// Function for displaying the time when programming the clock or alarm. Argument 't' is the Time to be
// displayed, argument '*disp' is a pointer to the seven segment display to output the time on, Argument
// 'selection' is the status of the board switches.
void displayTimeBlink(struct Time *t, XGpio *disp, u32 selection)
{
	// Extract digits of the Time. Even indices are ones places, odd indices are tens places.
	int extractedDigits[6] =
	{
		t->second % 10,
		(int) t->second / 10,
		t->minute % 10,
		(int) t->minute / 10,
		t->hour % 10,
		(int) t->hour / 10
	};
	// Get the value of the timer.
	u32 timerVal = XTmrCtr_GetValue(&timer, 0);
	// Toggle whether display for selected second, minute, or hour is on or off
	if(timerVal > 0xFE8287BF)
		on = true;
	else
		on = false;
	// If on, display as normal.
	if (on)
	{
		displayTime(t, disp);
	}
	// Otherwise
	else
	{
		_Bool condition;					// boolean for the selected second, minute, or hour to blink
		for (int i = 0; i < 6; i++)			// for loop for the display
		{
			switch (selection)				// check state of the switches
			{
			// if switch 15 and/or switch 0 are on
			case 1:
			case 32769:
				condition = (i < 2);
				break;
			// if switch 15 and/or switch 1 are on
			case 2:
			case 32770:
				condition = (i > 1 && i < 4);
				break;
			// otherwise
			default:
				condition = (i > 3);
			}
			if(condition)					// if selected second, minute, or hour
			{
				// Andode of the display
				XGpio_SetDataDirection(disp, 2, dispPlace[i]);
				// Cathode of the display
				XGpio_SetDataDirection(disp, 1, dispDigit[extractedDigits[i]]);
				// Delay to avoid flickering.
				MB_Sleep(2);
			}
			else							// others off
			{
				// Andode of the display
				XGpio_SetDataDirection(disp, 2, dispPlace[i]);
				// Cathode of the display
				XGpio_SetDataDirection(disp, 1, dispDigit[10]);
				// Delay to avoid flickering.
				MB_Sleep(2);
			}
		}
	}
}

// Function for checking if the alarm should be triggered. Only called if the alarm is enabled first.
void checkAlarm(struct Time t)
{
	if (t.second == t.alarm->second)				// Are the seconds the same?
		if (t.minute == t.alarm->minute)			// Are the minutes the same?
			if(t.hour == t.alarm->hour)				// Are the hours the same?
				alarmTriggered = true;				// Set alarm to trigger.
}
