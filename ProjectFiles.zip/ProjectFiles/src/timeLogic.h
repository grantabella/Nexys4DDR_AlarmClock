#include "xgpio.h"
/*
 * Time structure:
 * 		isHour12	:	boolean: if true, clock is 12 hour.
 * 								 if false, clock is 24 hour.
 * 		alarmOn		:	boolean: if true, alarm is enabled.
 * 								 if false, alarm is not enabled.
 * 		hour		:	integer for clock hour
 * 		minute		:	integer for clock minute
 * 		second		:	integer for clock second
 * 		alarm		:	pointer to another Time structure. The
 * 						Time assigned to this is the clock's
 * 						alarm.
 */

struct Time
{
  _Bool isHour12;
  _Bool alarmOn;
  int hour;
  int minute;
  int second;
  struct Time *alarm;
};

/*
 * Prototypes for functions related to the logic and programming of a Time structure:
 * 		setTime				:	assigns a time to a Time structure t.
 * 								Arguments are second, minute, and hour
 * 								values as well as the structure.
 * 		incrementSecond		:	increments the second value of a Time
 * 								structure. Argument is the structure.
 * 		incrementMinute		:	increments the minute value of a Time
 * 								structure. Only called in incrementSecond().
 * 								Argument is the structure.
 * 		incrementHour		:	increments the hour value of a Time
 * 								structure. Only called in incrementMinute().
 * 								Argument is the structure.
 * 		progSecond			:	adds a signed value to the second value of
 * 								a Time structue. Arguments are the structure
 * 								and the signed value to be added. Only called
 * 								in btn_handler().
 * 		progMinute			:	adds a signed value to the minute value of
 * 								a Time structue. Arguments are the structure
 * 								and the signed value to be added. Only called
 * 								in btn_handler().
 * 		progHour			:	adds a signed value to the hour value of a
 * 								Time structue. Arguments are the structure
 * 								and the signed value to be added. Only called
 * 								in btn_handler().
 *
 * */
void setTime(struct Time *t, int hr, int min, int sec);
void incrementSecond(struct Time *t);
void incrementMinute(struct Time *t);
void incrementHour(struct Time *t);
void progSecond(struct Time *t, int val);
void progMinute(struct Time *t, int val);
void progHour(struct Time *t, int val);
void displayTime(struct Time *t, XGpio *disp);

